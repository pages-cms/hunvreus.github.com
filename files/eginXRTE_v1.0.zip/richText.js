// Cross-Browser Rich Text Editor
// http://www.kevinroth.com/rte/demo.htm
// Written by Kevin Roth (kevin@NOSPAMkevinroth.com - remove NOSPAM)
// Visit the support forums at http://www.kevinroth.com/forums/index.php?c=2
// This code is public domain. Redistribution and use of this code, with or without modification, is permitted.

//init variables
var isRichText = false;
var rng;
var currentRTE;
var allRTEs = '';

var isIE;
var isGecko;
var isSafari;
var isKonqueror;

var generateXHTML = true;

var lang = 'en';
var encoding = 'iso-8859-1';

// *********** addEvent ***********
// Cross browser function to handle events
function addEvent(obj, evType, fn, useCapture){
  if (obj.addEventListener){
    obj.addEventListener(evType, fn, useCapture);
    return true;
  } else if (obj.attachEvent){
    var r = obj.attachEvent("on"+evType, fn);
    return r;
  }
}

// Add (in a clean way) the function to set the RTEs on window loading (so that it is not overriden by another window.onload definition...)
addEvent(window, 'load', function() {
	initRTE(true);
	var rteArray = [];
	var tagArray = document.getElementsByTagName('textarea');
	var i;
	for(i in tagArray) {
		if (tagArray[i].className) {
			if(/RTE/.test(tagArray[i].className)) {
				rteArray.push(tagArray[i]);
			}
		}
	}
	var i = 0;
	for (i in rteArray) {
      // before  we actually replace the textareas with RTEs we add the submit event on forms
		// for this we browse the parents of the input until we find a form
		var rteParent = rteArray[i];
		while ((rteParent.tagName != 'FORM') && (rteParent.tagName != 'BODY')) {
		  rteParent = rteParent.parentNode;
		}
		if (rteParent.tagName == 'FORM') {
		  addEvent(rteParent, 'submit', function() {updateRTEs();});
		}
		var RTEButtons = rteArray[i].getAttribute('buttons');
		if (!RTEButtons) RTEButtons = true;
		var RTEContent = rteArray[i].value;
		var RTECSSFile = rteArray[i].getAttribute('cssFile');
		var RTEHeight = rteArray[i].getAttribute('height');
		if (!RTEHeight) RTEHeight = rteArray[i].style.height;
		if (!RTEHeight) RTEHeight = '250px';
		var RTEName = rteArray[i].name;
		// If there is no name defined, then use the id. If there is no id either, then give an incremental name
		// THIS CASE SHOULD NEVER HAPPEN SINCE THE TEXTAREA IS SUPPOSED TO HAVE A NAME
		if (!RTEName) RTEName = rteArray[i].style.id;
		if (!RTEName) RTEName = 'rte_' + i;
		var RTEReadonly = rteArray[i].readOnly;
		var RTEWidth = rteArray[i].getAttribute('width');
		if (!RTEWidth) RTEWidth = rteArray[i].style.width;
		if (!RTEWidth) RTEWidth = '100%';
		writeRichText(rteArray[i], RTEName, RTEContent, RTEWidth, RTEHeight, RTEButtons, RTECSSFile, RTEReadonly);
	}
}, false);

function initRTE(genXHTML) {
	//set browser vars
	var ua = navigator.userAgent.toLowerCase();
	isIE = ((ua.indexOf("msie") != -1) && (ua.indexOf("opera") == -1) && (ua.indexOf("webtv") == -1)); 
	isGecko = (ua.indexOf("gecko") != -1);
	isSafari = (ua.indexOf("safari") != -1);
	isKonqueror = (ua.indexOf("konqueror") != -1);

	//check to see if designMode mode is available
	//Safari/Konqueror think they are designMode capable even though they are not
	if (document.getElementById && document.designMode && !isSafari && !isKonqueror) {
		isRichText = true;
	}
	
	if (isIE) {
		document.onmouseover = raiseButton;
		document.onmouseout  = normalButton;
		document.onmousedown = lowerButton;
		document.onmouseup   = raiseButton;
	}
}

function writeRichText(textarea, rte, html, width, height, buttons, cssFile, readOnly) {
	if (isRichText) {
		if (allRTEs.length > 0) allRTEs += ";";
		allRTEs += rte;
		if (readOnly) buttons = false;
		var RTECode = "";
		if (buttons == true) {
			RTECode += '		<ul class="rteButtons wysiwyg">';
			// Format
			RTECode += '			<li title="Font Attributes" class="fontAttributes">';
			RTECode += '      		<select id="formatblock_' + rte + '" onchange="selectFont(\'' + rte + '\', this.id);">';
			RTECode += '					<option value="">Style</option>';
			RTECode += '					<option value="<p>">Paragraph</option>';
			RTECode += '					<option value="<h1>">Heading 1</option>';
			RTECode += '					<option value="<h2>">Heading 2</option>';
			RTECode += '					<option value="<h3>">Heading 3</option>';
			RTECode += '					<option value="<h4>">Heading 4</option>';
			RTECode += '					<option value="<h5>">Heading 5</option>';
			RTECode += '					<option value="<h6>">Heading 6</option>';
			RTECode += '					<option value="<address>">Address</option>';
			RTECode += '					<option value="<pre>">Formatted</option>';
			RTECode += '				</select>';
			RTECode += '				<select id="fontname_' + rte + '" onchange="selectFont(\'' + rte + '\', this.id)">';
			RTECode += '					<option value="Font" selected>Font</option>';
			RTECode += '					<option value="Arial, Helvetica, sans-serif">Arial</option>';
			RTECode += '					<option value="Courier New, Courier, mono">Courier New</option>';
			RTECode += '					<option value="Times New Roman, Times, serif">Times New Roman</option>';
			RTECode += '					<option value="Verdana, Arial, Helvetica, sans-serif">Verdana</option>';
			RTECode += '				</select>';
			RTECode += '				<select unselectable="on" id="fontsize_' + rte + '" onchange="selectFont(\'' + rte + '\', this.id);">';
			RTECode += '					<option value="Size" selected>Size</option>';
			RTECode += '					<option value="1">1 (8 pt)</option>';
			RTECode += '					<option value="2">2 (10 pt)</option>';
			RTECode += '					<option value="3">3 (12pt)</option>';
			RTECode += '					<option value="4">4 (14pt)</option>';
			RTECode += '					<option value="5">5 (18pt)</option>';
			RTECode += '					<option value="6">6 (24pt)</option>';
			RTECode += '					<option value="7">7 (36pt)</option>';
			RTECode += '				</select>';
			RTECode += '			</li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'bold\', \'\')" title="Bold" class="bold">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'italic\', \'\')" title="Italic" class="italic">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'underline\', \'\')" title="Underline" class="underline">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'prompt\', \'forecolorPrompt_' + rte + '\')" title="Text Color" id="forecolor_' + rte + '" class="foreColor">&nbsp;</a>' + writeColorPrompt(rte, 'fore') + '</li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'prompt\', \'hilitecolorPrompt_' + rte + '\')" title="Background Color" id="hilitecolor_' + rte + '" class="hiliteColor">&nbsp;</a>' + writeColorPrompt(rte, 'hilite') + '</li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'removeformat\', \'\')" title="Remove Format" class="removeFormat">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'Strikethrough\')" title="Strikethrough" class="strikethrough">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'Subscript\')" title="Subscript" class="subscript">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'Superscript\')" title="Superscript" class="superscript">&nbsp;</a></li>';
			RTECode += '			<li class="expander expanded" level="3"><a>&nbsp;</a></li>';
			// Alignment, indent and lists
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'justifyleft\', \'\')" title="Align Left" class="justifyLeft">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'justifycenter\', \'\')" title="Center" class="justifyCenter">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'justifyright\', \'\')" title="Align Right" class="justifyRight">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'justifyfull\', \'\')" title="Justify Full" class="justifyFull">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'insertunorderedlist\', \'\')" title="Unordered List" class="unorderedList">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'insertorderedlist\', \'\')" title="Ordered List" class="orderedList">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'outdent\', \'\')" title="Outdent" class="outdent">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'indent\', \'\')" title="Indent" class="indent">&nbsp;</a></li>';
			RTECode += '			<li class="expander expanded" level="3"><a>&nbsp;</a></li>';
			RTECode += '		</ul>';
			RTECode += '		<ul class="rteButtons" id="buttonsSecondRow_' + rte + '">';
			// Insert
			RTECode += '			<li class="wysiwyg"><a href="javascript:rteCommand(\'' + rte + '\', \'inserthorizontalrule\', \'\')" title="Horizontal Rule" class="horizontalRule">&nbsp;</a></li>';
			RTECode += '			<li class="wysiwyg"><a href="javascript:rteCommand(\'' + rte + '\', \'prompt\', \'hyperlinkPrompt_' + rte + '\')" title="Insert Link" class="insertLink">&nbsp;</a>' + writeHyperlinkPrompt(rte) + '</li>';
			RTECode += '			<li class="wysiwyg"><a href="javascript:rteCommand(\'' + rte + '\', \'unlink\')" title="Delete Link" class="deleteLink">&nbsp;</a></li>';
			RTECode += '			<li class="wysiwyg"><a href="javascript:rteCommand(\'' + rte + '\', \'prompt\', \'imagePrompt_' + rte + '\')" title="Add Image" class="addImage">&nbsp;</a>' + writeImagePrompt(rte) + '</li>';
			RTECode += '			<li class="wysiwyg"><a href="javascript:rteCommand(\'' + rte + '\', \'prompt\', \'tablePrompt_' + rte + '\')" title="Insert Table" class="insertTable">&nbsp;</a>' + writeTablePrompt(rte) + '</li>';		
			RTECode += '			<li class="separator wysiwyg">&nbsp;</li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'undo\', \'\')" title="Undo" class="undo">&nbsp;</a></li>';
			RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'redo\', \'\')" title="Redo" class="redo">&nbsp;</a></li>';
			// Copy, cut and paste
			if (!isGecko) {
				RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'cut\')" title="Cut" class="cut">&nbsp;</a></li>';
				RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'copy\')" title="Copy" class="copy">&nbsp;</a></li>';
				RTECode += '			<li><a href="javascript:rteCommand(\'' + rte + '\', \'paste\')" title="Paste" class="paste">&nbsp;</a></li>';
			}
			// Checkspell (IE only)
			if (isIE) {
				RTECode += '		<li><a href="javascript:checkspell()" title="Spell Check" class="spellCheck">&nbsp;</a></li>';
			}
			RTECode += '		</ul>';
		}
		// Toggle thumbs to switch WYSIWYG/HTML mode
		if (!readOnly) {
			if (buttons == true) {
				RTECode += '	<div class="toggle">';
			}
			else {
				RTECode += '	<div class="toggle noButtons">';
			}
			RTECode += '		<a href="javascript:toggleHTMLSrc(\'' + rte + '\', \'wysiwyg\');" id="seeWysiwyg_' + rte + '" title="Source" class="active">WYSIWYG</a>';
			RTECode += '		<a href="javascript:toggleHTMLSrc(\'' + rte + '\', \'html\')" id="seeHtml_' + rte + '" title="Source" class="inactive">HTML</a>';
			RTECode += '	</div>';
		}
		// Rich Text area
		RTECode += '	<p class="textFrame">';
		RTECode += '		<iframe id="' + rte + '" name="' + rte + '" height="' + height + '" width="100%" frameborder="0" vspace="0" hspace="0" marginheight="0" marginwidth="0" align="center"></iframe>';
		RTECode += '	</p>';
		RTECode += '	<input type="hidden" id="hdn' + rte + '" name="' + rte + '" value="" class="button">';
		// Create the container of the Rich Text Editor code
		var RTENode = document.createElement('div');
		RTENode.id = 'richTextEditorContainer_' + rte;
		RTENode.className = 'richTextEditor';
		RTENode.style.width = width;
		// Add the Rich Text Editor and delete the textarea
		textarea.parentNode.insertBefore(RTENode, textarea);
		textarea.parentNode.removeChild(textarea);
		RTENode.innerHTML = RTECode;
		if (buttons == true) {
			// Set the explanders and the color palettes
			setExpanders(RTENode);
			initColorPalette(rte, 'hilite');
			initColorPalette(rte, 'fore');
		}
		// Set the hidden content input and enable design mode
		document.getElementById('hdn' + rte).value = html;
		enableDesignMode(rte, html, cssFile, readOnly);
	}
}

// 
function enableDesignMode(rte, html, cssFile, readOnly) {
	var frameHtml = "<html id=\"" + rte + "\">\n";
	frameHtml += "<head>\n";
	if (cssFile && (cssFile.length > 0)) {
		frameHtml += "<link media=\"all\" type=\"text/css\" href=\"" + cssFile + "\" rel=\"stylesheet\">\n";
	} else {
		frameHtml += "<style>\n";
		frameHtml += "body {\n";
		frameHtml += "	background:white;\n";
		frameHtml += "	margin:0px;\n";
		frameHtml += "	padding:5px;\n";
		frameHtml += "}\n";
		frameHtml += "</style>\n";
	}
	frameHtml += "</head>\n";
	frameHtml += "<body>\n";
	frameHtml += html + "\n";
	frameHtml += "</body>\n";
	frameHtml += "</html>";
	
	if (document.all) {
		var oRTE = frames[rte].document;
		oRTE.open();
		oRTE.write(frameHtml);
		oRTE.close();
		if (!readOnly) {
			oRTE.designMode = "On";
			frames[rte].document.attachEvent("onkeypress", function evt_ie_keypress(event) {ieKeyPress(event, rte);});
		}
	} else {
		try {
			if (!readOnly) document.getElementById(rte).contentDocument.designMode = "on";
			try {
				var oRTE = document.getElementById(rte).contentWindow.document;
				oRTE.open();
				oRTE.write(frameHtml);
				oRTE.close();
				if (isGecko && !readOnly) {
					//attach a keyboard handler for gecko browsers to make keyboard shortcuts work
					oRTE.addEventListener("keypress", geckoKeyPress, true);
				}
			} catch (e) {
				alert("Error preloading content.");
			}
		} catch (e) {
			//gecko may take some time to enable design mode.
			//Keep looping until able to set.
			if (isGecko) {
				setTimeout("enableDesignMode('" + rte + "', '" + html + "', " + readOnly + ");", 10);
			} else {
				return false;
			}
		}
	}
}

function updateRTE(rte) {
	if (!isRichText) return;
	
	//check for readOnly mode
	var readOnly = false;
	if (document.all) {
		if (frames[rte].document.designMode != "On") readOnly = true;
	} else {
		if (document.getElementById(rte).contentDocument.designMode != "on") readOnly = true;
	}
	
	if (isRichText && !readOnly) {
		//if viewing source, switch back to design view
		toggleHTMLSrc(rte, 'wysiwyg');
		setHiddenVal(rte);
	}
}

function setHiddenVal(rte) {
	//set hidden form field value for current rte
	var oHdnField = document.getElementById('hdn' + rte);
	//convert html output to xhtml (thanks Timothy Bell and Vyacheslav Smolin!)
	if (oHdnField.value == null) oHdnField.value = "";
	if (document.all) {
		if (generateXHTML) {
			oHdnField.value = get_xhtml(frames[rte].document.body, lang, encoding);
		} else {
			oHdnField.value = frames[rte].document.body.innerHTML;
		}
	} else {
		if (generateXHTML) {
			oHdnField.value = get_xhtml(document.getElementById(rte).contentWindow.document.body, lang, encoding);
		} else {
			oHdnField.value = document.getElementById(rte).contentWindow.document.body.innerHTML;
		}
	}
	
	//if there is no content (other than formatting) set value to nothing
	if (stripHTML(oHdnField.value.replace("&nbsp;", " ")) == "" &&
		oHdnField.value.toLowerCase().search("<hr") == -1 &&
		oHdnField.value.toLowerCase().search("<img") == -1) oHdnField.value = "";
}

function updateRTEs() {
	var vRTEs = allRTEs.split(";");
	for (var i = 0; i < vRTEs.length; i++) {
		updateRTE(vRTEs[i]);
	}
}

// *********** rteCommand ***********
// Format the text with the required command
function rteCommand(rte, command, option) {
	if (command == 'prompt') {
		setRange(rte);
		currentRTE = rte;
		// Toggle the specified prompt and hide the others
		if (option != 'forecolorPrompt_' + rte) closeElement('forecolorPrompt_' + rte);
		if (option != 'hilitecolorPrompt_' + rte) closeElement('hilitecolorPrompt_' + rte);
		if (option != 'hyperlinkPrompt_' + rte) closeElement('hyperlinkPrompt_' + rte);
		if (option != 'imagePrompt_' + rte) closeElement('imagePrompt_' + rte);
		if (option != 'tablePrompt_' + rte) closeElement('tablePrompt_' + rte);
		toggleElement(option);
	}
	else {
		// Hide all the prompts
		closeElement('forecolorPrompt_' + rte);
		closeElement('hilitecolorPrompt_' + rte);
		closeElement('hyperlinkPrompt_' + rte);
		closeElement('imagePrompt_' + rte);
		closeElement('tablePrompt_' + rte);
	}
	//function to perform command
	var oRTE;
	if (document.all) {
		oRTE = frames[rte];
	} else {
		oRTE = document.getElementById(rte).contentWindow;
	}
	
	try {
		oRTE.focus();
	  	oRTE.document.execCommand(command, false, option);
		oRTE.focus();
	} catch (e) {
//		alert(e);
//		setTimeout("rteCommand('" + rte + "', '" + command + "', '" + option + "');", 10);
	}
}

function toggleHTMLSrc(rte, mode) {
	//contributed by Bob Hutzel (thanks Bob!)
	var oHdnField = document.getElementById('hdn' + rte);
	if ((mode == 'html') && (document.getElementById('seeHtml_' + rte).className == 'inactive')) {
		document.getElementById('richTextEditorContainer_' + rte).className = 'richTextEditor richTextEditorSource';
		document.getElementById('seeHtml_' + rte).className = 'active';
		document.getElementById('seeWysiwyg_' + rte).className = 'inactive';
		setHiddenVal(rte);
		if (document.all) {
			frames[rte].document.body.innerText = oHdnField.value;
		} else {
			var oRTE = document.getElementById(rte).contentWindow.document;
			var htmlSrc = oRTE.createTextNode(oHdnField.value);
			oRTE.body.innerHTML = "";
			oRTE.body.appendChild(htmlSrc);
		}
	}
	else if ((mode == 'wysiwyg') && (document.getElementById('seeWysiwyg_' + rte).className == 'inactive')) {
		document.getElementById('richTextEditorContainer_' + rte).className = 'richTextEditor';
		document.getElementById('seeHtml_' + rte).className = 'inactive';
		document.getElementById('seeWysiwyg_' + rte).className = 'active';
		if (document.all) {
			//fix for IE
			var output = escape(frames[rte].document.body.innerText);
			output = output.replace("%3CP%3E%0D%0A%3CHR%3E", "%3CHR%3E");
			output = output.replace("%3CHR%3E%0D%0A%3C/P%3E", "%3CHR%3E");
			frames[rte].document.body.innerHTML = unescape(output);
		} else {
			var oRTE = document.getElementById(rte).contentWindow.document;
			var htmlSrc = oRTE.body.ownerDocument.createRange();
			htmlSrc.selectNodeContents(oRTE.body);
			oRTE.body.innerHTML = htmlSrc.toString();
		}
	}
}

function selectFont(rte, selectname) {
	//function to handle font changes
	var idx = document.getElementById(selectname).selectedIndex;
	// First one is always a label
	if (idx != 0) {
		var selected = document.getElementById(selectname).options[idx].value;
		var cmd = selectname.replace('_' + rte, '');
		rteCommand(rte, cmd, selected);
		document.getElementById(selectname).selectedIndex = 0;
	}
}

function insertHTML(html) {
	try {
		//function to add HTML -- thanks dannyuk1982
		var rte = currentRTE;
		
		var oRTE;
		if (document.all) {
			oRTE = frames[rte];
		} else {
			oRTE = document.getElementById(rte).contentWindow;
		}
		
		oRTE.focus();
		if (document.all) {
			var oRng = oRTE.document.selection.createRange();
			oRng.pasteHTML(html);
			oRng.collapse(false);
			oRng.select();
		} else {
			oRTE.document.execCommand('insertHTML', false, html);
		}
	}
	catch (e) {
		// TO REFINE
		// Happen when something is selected out of the rich text iframe
	}
}

function setRange(rte) {
	//function to store range of current selection
	var oRTE;
	if (document.all) {
		oRTE = frames[rte];
		var selection = oRTE.document.selection; 
		if (selection != null) rng = selection.createRange();
	} else {
		oRTE = document.getElementById(rte).contentWindow;
		var selection = oRTE.getSelection();
		rng = selection.getRangeAt(selection.rangeCount - 1).cloneRange();
	}
	return rng;
}

function stripHTML(oldString) {
	//function to strip all html
	var newString = oldString.replace(/(<([^>]+)>)/ig,"");
	
	//replace carriage returns and line feeds
   newString = newString.replace(/\r\n/g," ");
   newString = newString.replace(/\n/g," ");
   newString = newString.replace(/\r/g," ");
	
	//trim string
	newString = trim(newString);
	
	return newString;
}

function trim(inputString) {
   // Removes leading and trailing spaces from the passed string. Also removes
   // consecutive spaces and replaces it with one space. If something besides
   // a string is passed in (null, custom object, etc.) then return the input.
   if (typeof inputString != "string") return inputString;
   var retValue = inputString;
   var ch = retValue.substring(0, 1);
	
   while (ch == " ") { // Check for spaces at the beginning of the string
      retValue = retValue.substring(1, retValue.length);
      ch = retValue.substring(0, 1);
   }
   ch = retValue.substring(retValue.length - 1, retValue.length);
	
   while (ch == " ") { // Check for spaces at the end of the string
      retValue = retValue.substring(0, retValue.length - 1);
      ch = retValue.substring(retValue.length - 1, retValue.length);
   }
	
	// Note that there are two spaces in the string - look for multiple spaces within the string
   while (retValue.indexOf("  ") != -1) {
		// Again, there are two spaces in each of the strings
      retValue = retValue.substring(0, retValue.indexOf("  ")) + retValue.substring(retValue.indexOf("  ") + 1, retValue.length);
   }
   return retValue; // Return the trimmed string back to the user
}

//********************
//Gecko-Only Functions
//********************
function geckoKeyPress(evt) {
	//function to add bold, italic, and underline shortcut commands to gecko RTEs
	//contributed by Anti Veeranna (thanks Anti!)
	var rte = evt.target.id;
	
	if (evt.ctrlKey) {
		var key = String.fromCharCode(evt.charCode).toLowerCase();
		var cmd = '';
		switch (key) {
			case 'b': cmd = "bold"; break;
			case 'i': cmd = "italic"; break;
			case 'u': cmd = "underline"; break;
		};

		if (cmd) {
			rteCommand(rte, cmd, null);
			
			// stop the event bubble
			evt.preventDefault();
			evt.stopPropagation();
		}
 	}
}

//*****************
//IE-Only Functions
//*****************
function ieKeyPress(evt, rte) {
	var key = (evt.which || evt.charCode || evt.keyCode);
	var stringKey = String.fromCharCode(key).toLowerCase();
	
//the following breaks list and indentation functionality in IE (don't use)
//	switch (key) {
//		case 13:
//			//insert <br> tag instead of <p>
//			//change the key pressed to null
//			evt.keyCode = 0;
//			
//			//insert <br> tag
//			currentRTE = rte;
//			insertHTML('<br>');
//			break;
//	};
}

function checkspell() {
	//function to perform spell check
	try {
		var tmpis = new ActiveXObject("ieSpell.ieSpellExtension");
		tmpis.CheckAllLinkedDocuments(document);
	}
	catch(exception) {
		if(exception.number==-2146827859) {
			if (confirm("ieSpell not detected.  Click Ok to go to download page."))
				window.open("http://www.iespell.com/download.php","DownLoad");
		} else {
			alert("Error Loading ieSpell: Exception " + exception.number);
		}
	}
}

function raiseButton(e) {
	var el = window.event.srcElement;
	
	className = el.className;
	if (className == 'rteImage' || className == 'rteImageLowered') {
		el.className = 'rteImageRaised';
	}
}

function normalButton(e) {
	var el = window.event.srcElement;
	
	className = el.className;
	if (className == 'rteImageRaised' || className == 'rteImageLowered') {
		el.className = 'rteImage';
	}
}

function lowerButton(e) {
	var el = window.event.srcElement;
	
	className = el.className;
	if (className == 'rteImage' || className == 'rteImageRaised') {
		el.className = 'rteImageLowered';
	}
}

// *****************
// Prompts functions
// *****************

// *********** closeElement ***********
// Hide the specified element, variable can be string or object
function closeElement(element) {
	if (document.getElementById(element)) element = document.getElementById(element);
	element.style.display = 'none';
}

// *********** closeElement ***********
// Display the specified element, variable can be string or object
function openElement(element) {
	if (document.getElementById(element)) element = document.getElementById(element);
	element.style.display = 'block';
}

// *********** toggleElement ***********
// display the element which id is elementID
function toggleElement(element) {
	if (document.getElementById(element)) element = document.getElementById(element);
	if (element.style.display == 'block') {
		closeElement(element);
	}
	else {
		openElement(element);
	}
}

function setEnterKey(e, action, option) {
	var characterCode;
	if (e && e.which) {
		e = e;
		characterCode = e.which;
	}
	else{
		e = event;
		characterCode = e.keyCode;
	}
	if (characterCode == 13) {
		if (action.length > 0) {
			eval(action + '(\'' + option + '\');');
		}
		return false;
	}
	else {
		return true;
	}
}

// *********** writeColorPrompt ***********
// Write the color chart prompt
function writeColorPrompt(rte, prefix) {
	var colorPromptCode = '';
	colorPromptCode += '<div id="' + prefix + 'colorPrompt_' + rte + '" class="prompt color">';
	colorPromptCode += '	<table cellspacing="0" id="' + prefix + 'colorTable_' + rte + '">';
	colorPromptCode += '		<tr>';
	colorPromptCode += '			<td id="#FFFFFF">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFCCCC">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFCC99">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFFF99">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFFFCC">&nbsp;</td>';
	colorPromptCode += '			<td id="#99FF99">&nbsp;</td>';
	colorPromptCode += '			<td id="#99FFFF">&nbsp;</td>';
	colorPromptCode += '			<td id="#CCFFFF">&nbsp;</td>';
	colorPromptCode += '			<td id="#CCCCFF">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFCCFF">&nbsp;</td>';
	colorPromptCode += '		</tr>';
	colorPromptCode += '		<tr>';
	colorPromptCode += '			<td id="#CCCCCC">&nbsp;</td>';
	colorPromptCode += '			<td id="#FF6666">&nbsp;</td>';
	colorPromptCode += '			<td id="#FF9966">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFFF66">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFFF33">&nbsp;</td>';
	colorPromptCode += '			<td id="#66FF99">&nbsp;</td>';
	colorPromptCode += '			<td id="#33FFFF">&nbsp;</td>';
	colorPromptCode += '			<td id="#66FFFF">&nbsp;</td>';
	colorPromptCode += '			<td id="#9999FF">&nbsp;</td>';
	colorPromptCode += '			<td id="#FF99FF">&nbsp;</td>';
	colorPromptCode += '		</tr>';
	colorPromptCode += '		<tr>';
	colorPromptCode += '			<td id="#C0C0C0">&nbsp;</td>';
	colorPromptCode += '			<td id="#FF0000">&nbsp;</td>';
	colorPromptCode += '			<td id="#FF9900">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFCC66">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFFF00">&nbsp;</td>';
	colorPromptCode += '			<td id="#33FF33">&nbsp;</td>';
	colorPromptCode += '			<td id="#66CCCC">&nbsp;</td>';
	colorPromptCode += '			<td id="#33CCFF">&nbsp;</td>';
	colorPromptCode += '			<td id="#6666CC">&nbsp;</td>';
	colorPromptCode += '			<td id="#CC66CC">&nbsp;</td>';
	colorPromptCode += '		</tr>';
	colorPromptCode += '		<tr>';
	colorPromptCode += '			<td id="#999999">&nbsp;</td>';
	colorPromptCode += '			<td id="#CC0000">&nbsp;</td>';
	colorPromptCode += '			<td id="#FF6600">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFCC33">&nbsp;</td>';
	colorPromptCode += '			<td id="#FFCC00">&nbsp;</td>';
	colorPromptCode += '			<td id="#33CC00">&nbsp;</td>';
	colorPromptCode += '			<td id="#00CCCC">&nbsp;</td>';
	colorPromptCode += '			<td id="#3366FF">&nbsp;</td>';
	colorPromptCode += '			<td id="#6633FF">&nbsp;</td>';
	colorPromptCode += '			<td id="#CC33CC">&nbsp;</td>';
	colorPromptCode += '		</tr>';
	colorPromptCode += '		<tr>';
	colorPromptCode += '			<td id="#666666">&nbsp;</td>';
	colorPromptCode += '			<td id="#990000">&nbsp;</td>';
	colorPromptCode += '			<td id="#CC6600">&nbsp;</td>';
	colorPromptCode += '			<td id="#CC9933">&nbsp;</td>';
	colorPromptCode += '			<td id="#999900">&nbsp;</td>';
	colorPromptCode += '			<td id="#009900">&nbsp;</td>';
	colorPromptCode += '			<td id="#339999">&nbsp;</td>';
	colorPromptCode += '			<td id="#3333FF">&nbsp;</td>';
	colorPromptCode += '			<td id="#6600CC">&nbsp;</td>';
	colorPromptCode += '			<td id="#993399">&nbsp;</td>';
	colorPromptCode += '		</tr>';
	colorPromptCode += '		<tr>';
	colorPromptCode += '			<td id="#333333">&nbsp;</td>';
	colorPromptCode += '			<td id="#660000">&nbsp;</td>';
	colorPromptCode += '			<td id="#993300">&nbsp;</td>';
	colorPromptCode += '			<td id="#996633">&nbsp;</td>';
	colorPromptCode += '			<td id="#666600">&nbsp;</td>';
	colorPromptCode += '			<td id="#006600">&nbsp;</td>';
	colorPromptCode += '			<td id="#336666">&nbsp;</td>';
	colorPromptCode += '			<td id="#000099">&nbsp;</td>';
	colorPromptCode += '			<td id="#333399">&nbsp;</td>';
	colorPromptCode += '			<td id="#663366">&nbsp;</td>';
	colorPromptCode += '		</tr>';
	colorPromptCode += '		<tr>';
	colorPromptCode += '			<td id="#000000">&nbsp;</td>';
	colorPromptCode += '			<td id="#330000">&nbsp;</td>';
	colorPromptCode += '			<td id="#663300">&nbsp;</td>';
	colorPromptCode += '			<td id="#663333">&nbsp;</td>';
	colorPromptCode += '			<td id="#333300">&nbsp;</td>';
	colorPromptCode += '			<td id="#003300">&nbsp;</td>';
	colorPromptCode += '			<td id="#003333">&nbsp;</td>';
	colorPromptCode += '			<td id="#000066">&nbsp;</td>';
	colorPromptCode += '			<td id="#330099">&nbsp;</td>';
	colorPromptCode += '			<td id="#330033">&nbsp;</td>';
	colorPromptCode += '		</tr>';
	colorPromptCode += '		<tr>';
	colorPromptCode += '			<th colspan="5" id="' + prefix + 'colorPreview_' + rte + '" class="preview">Preview</th>';
	colorPromptCode += '			<th colspan="5" id="' + prefix + 'colorSelected_' + rte + '" class="selected">Selected</th>';
	colorPromptCode += '		</tr>';
	colorPromptCode += '		<tr>';
	colorPromptCode += '			<th colspan="10" id="' + prefix + 'colorSelected_' + rte + '" class="code">';
	colorPromptCode += '				<input type="text" name="' + prefix + 'colorSelectedInput_' + rte + '" id="' + prefix + 'colorSelectedInput_' + rte + '" value="#000000" onKeyUp="refreshSelectedColor(\'' + rte + '\', \'' + prefix + '\');" onKeyPress="return setEnterKey(event, \'\', \'\');"/>';
	colorPromptCode += '				<input type="hidden" name="' + prefix + 'colorPreviewInput_' + rte + '" id="' + prefix + 'colorPreviewInput_' + rte + '" value="#000000"/>';
	colorPromptCode += '			</th>';
	colorPromptCode += '		</tr>';
	colorPromptCode += '	</table>';
	colorPromptCode += '	<input type="button" value="Cancel" onClick="closeElement(\'' + prefix + 'colorPrompt_' + rte + '\')" class="button"/>';
	colorPromptCode += '	<input type="button" value="Apply" onClick="setInputColor(\'' + rte + '\', \'' + prefix + '\')" class="button"/>';
	colorPromptCode += '</div>';
	return colorPromptCode;
}

// *********** initColorPalette ***********
// Initiate the color chart table : set table cells onMouseOver, onMouseOut and onClick properties
function initColorPalette(rte, prefix) {
	var colorTable = document.getElementById(prefix + 'colorTable_' + rte);
	for (i=0; i<colorTable.childNodes.length; i++) {
		var firstNode = colorTable.childNodes[i];
		if (firstNode.nodeName=="TBODY") {
			for (j=0; j<firstNode.childNodes.length; j++) {
				var secondNode = firstNode.childNodes[j];
				if (secondNode.nodeName=="TR") {
					for (k=0; k<secondNode.childNodes.length; k++) {
						var thirdNode = secondNode.childNodes[k];
						if (thirdNode.nodeName=="TD") {
							thirdNode.onmouseover = function() {paletteOver(rte, prefix, this);};
							thirdNode.onmouseout = paletteOut;
							thirdNode.onclick = function() {paletteClick(rte, prefix, this);};
							thirdNode.style.background = thirdNode.id;
						}
					}
				}
			}
		}
	}
}

// *********** paletteOver ***********
// Update the preview color cell and input, add "over" to the class attribute
function paletteOver(rte, prefix, element) {
	element.className +=" over";
	document.getElementById(prefix + 'colorPreviewInput_' + rte).value = element.id;
	refreshPreviewColor(rte, prefix);	
}

// *********** paletteOut ***********
// Remove "over" from the class attribute
function paletteOut() {
	this.className -=" over";
}

// *********** paletteClick ***********
// Update the selected color cell and input
function paletteClick(rte, prefix, element) {
	document.getElementById(prefix + 'colorSelectedInput_' + rte).value = element.id;
	refreshSelectedColor(rte, prefix);
}

// *********** refreshPreviewColor ***********
// Update the preview color cell
function refreshPreviewColor(rte, prefix) {
	document.getElementById(prefix + 'colorPreview_' + rte).style.background = document.getElementById(prefix + 'colorPreviewInput_' + rte).value;
}

// *********** refreshSelectedColor ***********
// Update the selected color cell
function refreshSelectedColor(rte, prefix) {
	try {
		document.getElementById(prefix + 'colorSelected_' + rte).style.background = document.getElementById(prefix + 'colorSelectedInput_' + rte).value;
	} catch (e) {
		// Invalid color
	}
}

// *********** setInputColor ***********
// Get the selected color value and set the color
function setInputColor(rte, prefix) {
	var color = document.getElementById(prefix + 'colorSelectedInput_' + rte).value;
	if (document.all) {
		rng.select();
		if (prefix == 'hilite') prefix = 'back';
	}
	rteCommand(rte, prefix + 'color', color);
	closeElement(prefix + 'colorPrompt_' + rte);
}

// *********** writeHyperlinkPrompt ***********
// Write the hyperlink prompt
function writeHyperlinkPrompt (rte) {
	var hyperlinkPromptCode = '';
	hyperlinkPromptCode += '<div id="hyperlinkPrompt_' + rte + '" class="prompt hyperlink" style="display:none;">';
	// hyperlinkPromptCode += '<form action="" method="POST" name="form1" onsubmit="return false;">';
	hyperlinkPromptCode += '	<label>URL</label>';
	hyperlinkPromptCode += '	<input type="text" name="hyperlinkURL_' + rte + '" id="hyperlinkURL_' + rte + '" value="" onKeyPress="return setEnterKey(event, \'setHyperlink\', \'' + rte + '\');"/><br/>';
	hyperlinkPromptCode += '	<label>Title</label>';
	hyperlinkPromptCode += '	<input type="text" name="hyperlinkTitle_' + rte + '" id="hyperlinkTitle_' + rte + '" value="" onKeyPress="return setEnterKey(event, \'setHyperlink\', \'' + rte + '\');"/><br/>';
	hyperlinkPromptCode += '	<label>Target</label>';
	hyperlinkPromptCode += '	<select name="hyperlinkTarget_' + rte + '" id="hyperlinkTarget_' + rte + '"  onKeyPress="return setEnterKey(event, \'setHyperlink\', \'' + rte + '\');">';
	hyperlinkPromptCode += '		<option value="" selected></option>';
	hyperlinkPromptCode += '		<option value="_blank">_blank</option>';
	hyperlinkPromptCode += '		<option value="_parent">_parent</option>';
	hyperlinkPromptCode += '		<option value="_self">_self</option>';
	hyperlinkPromptCode += '		<option value="_top">_top</option>';
	hyperlinkPromptCode += '	</select><br/>';
	hyperlinkPromptCode += '	<input type="button" value="Cancel" onClick="closeElement(\'hyperlinkPrompt_' + rte + '\')" class="button"/>';
	hyperlinkPromptCode += '	<input type="button" value="Apply" onClick="setHyperlink(\'' + rte + '\')" class="button"/>';
	// hyperlinkPromptCode += '</form>';
	hyperlinkPromptCode += '</div>';
	return hyperlinkPromptCode;
}

// *********** setHyperlink ***********
// Set the rich text selection as a link defined by the hyperlink prompt
function setHyperlink (rte) {
	var hyperlinkURL = document.getElementById('hyperlinkURL_' + rte).value;
	var hyperlinkTitle = document.getElementById('hyperlinkTitle_' + rte).value;
	var hyperlinkTarget = document.getElementById('hyperlinkTarget_' + rte).value;
	var hyperlinkCode = '<a href=\"' + hyperlinkURL + '\"';
	if (hyperlinkTitle != '') hyperlinkCode += ' title=\"' + hyperlinkTitle + '\"';
	if (hyperlinkTarget != '') hyperlinkCode += ' target=\"' + hyperlinkTarget + '\"';
	if (isIE) {
		hyperlinkText = rng.htmlText;
	} else {
		hyperlinkText = rng.toString();
	}
	hyperlinkCode += '>' + hyperlinkText + '</a>';
	insertHTML(hyperlinkCode);
	closeElement('hyperlinkPrompt_' + rte);
}

// *********** writeImagePrompt ***********
// Write the image prompt
function writeImagePrompt (rte) {
	var imagePromptCode = '';
	imagePromptCode += '<div id="imagePrompt_' + rte + '" class="prompt image" style="display:none;">';
	imagePromptCode += '	<label for="imageURL_' + rte + '">URL</label>';
	imagePromptCode += '	<input type="text" name="imageURL_' + rte + '" id="imageURL_' + rte + '" value="" onKeyPress="return setEnterKey(event, \'insertImage\', \'' + rte + '\');"/><br/>';
	imagePromptCode += '	<label for="imageAlt_' + rte + '">Title</label>';
	imagePromptCode += '	<input type="text" name="imageTitle_' + rte + '" id="imageTitle_' + rte + '" value="" onKeyPress="return setEnterKey(event, \'insertImage\', \'' + rte + '\');"/><br/>';
	imagePromptCode += '	<label for="imageAlt_' + rte + '">Alt</label>';
	imagePromptCode += '	<input type="text" name="imageAlt_' + rte + '" id="imageAlt_' + rte + '" value="" onKeyPress="return setEnterKey(event, \'insertImage\', \'' + rte + '\');"/><br/>';
	imagePromptCode += '	<input type="button" value="Cancel" onClick="closeElement(\'imagePrompt_' + rte + '\')" class="button"/>';
	imagePromptCode += '	<input type="button" value="Insert" onClick="insertImage(\'' + rte + '\')" class="button"/>';
	imagePromptCode += '</div>';
	return imagePromptCode;
}

// *********** insertTable ***********
// Insert in the document the image defined in the image prompt
function insertImage(rte) {
	var imageURL = document.getElementById('imageURL_' + rte).value;
	var imageTitle = document.getElementById('imageTitle_' + rte).value;
	var imageAlt = document.getElementById('imageAlt_' + rte).value;
	var imageCode = '<img src=\"' + imageURL + '\"';
	if (imageTitle != '') imageCode += ' title=\"' + imageTitle + '\"';
	if (imageAlt != '') imageCode += ' alt=\"' + imageAlt + '\"';
	imageCode += '/>';
	insertHTML(imageCode);
	closeElement('imagePrompt_' + rte);
}

// *********** writeTablePrompt ***********
// Write the table prompt
function writeTablePrompt(rte) {
	var tablePromptCode = '';
	tablePromptCode += '<div id="tablePrompt_' + rte + '" class="prompt table" style="display:none;">';
	tablePromptCode += '	<fieldset><legend>Structure</legend>';
	tablePromptCode += '		<label>Rows</label>';
	tablePromptCode += '		<input type="text" id="tableRows_' + rte + '" value="2" onKeyPress="return setEnterKey(event, \'insertTable\', \'' + rte + '\');"/><br/>';
	tablePromptCode += '		<label>Cols</label>';
	tablePromptCode += '		<input type="text" id="tableCols_' + rte + '" value="2" onKeyPress="return setEnterKey(event, \'insertTable\', \'' + rte + '\');"/><br/>';
	tablePromptCode += '		<label>Height</label>';
	tablePromptCode += '		<input type="text" id="tableHeight_' + rte + '" value="" onKeyPress="return setEnterKey(event, \'insertTable\', \'' + rte + '\');"/><br/>';
	tablePromptCode += '		<label>Width</label>';
	tablePromptCode += '		<input type="text" id="tableWidth_' + rte + '" value="100%" onKeyPress="return setEnterKey(event, \'insertTable\', \'' + rte + '\');"/><br/>';
	tablePromptCode += '	</fieldset>';
	tablePromptCode += '	<fieldset><legend>Style</legend>';
	tablePromptCode += '		<label>Border</label>';
	tablePromptCode += '		<input type="text" id="tableBorder_' + rte + '" value="1" onKeyPress="return setEnterKey(event, \'insertTable\', \'' + rte + '\');"/><br/>';
	tablePromptCode += '		<label>Cellpadding</label>';
	tablePromptCode += '		<input type="text" id="tableCellpadding_' + rte + '" value="0" onKeyPress="return setEnterKey(event, \'insertTable\', \'' + rte + '\');"/><br/>';
	tablePromptCode += '		<label>Cellspacing</label>';
	tablePromptCode += '		<input type="text" id="tableCellspacing_' + rte + '" value="0" onKeyPress="return setEnterKey(event, \'insertTable\', \'' + rte + '\');"/><br/>';
	tablePromptCode += '	</fieldset>';
	tablePromptCode += '	<input type="button" value="Cancel" onClick="closeElement(\'tablePrompt_' + rte + '\')" class="button"/>';
	tablePromptCode += '	<input type="button" value="Insert" onClick="insertTable(\'' + rte + '\')" class="button"/>';
	tablePromptCode += '</div>';
	return tablePromptCode;
}

// *********** insertTable ***********
// Insert in the document the table defined in the table prompt
function insertTable(rte) {
	var tableCols = document.getElementById('tableCols_' + rte).value;
	var tableRows = document.getElementById('tableRows_' + rte).value;
	var tableHeight = document.getElementById('tableHeight_' + rte).value;
	var tableWidth = document.getElementById('tableWidth_' + rte).value;
	var tableBorder = document.getElementById('tableBorder_' + rte).value;
	var tableCellpadding = document.getElementById('tableCellpadding_' + rte).value;
	var tableCellspacing = document.getElementById('tableCellspacing_' + rte).value;
	var tableCode = '<table';
	if (tableHeight != '') tableCode += ' height=\"' + tableHeight + '\"';
	if (tableWidth != '') tableCode += ' width=\"' + tableWidth + '\"';
	if (tableBorder != '') tableCode += ' border=\"' + tableBorder + '\"';
	if (tableCellpadding != '') tableCode += ' cellpadding=\"' + tableCellpadding + '\"';
	if (tableCellspacing != '') tableCode += ' cellspacing=\"' + tableCellspacing + '\"';
	tableCode += '>';
	for (var i=0; i < tableRows; i++) {
		tableCode += '<tr>';
		for (var j=0; j < tableCols; j++) {
			tableCode += '<td></td>';
		}
		tableCode += '</tr>';
	}
	tableCode += '</table>';
	insertHTML(tableCode);
	closeElement('tablePrompt_' + rte);
}

// *********** setExpanders ***********
// Find the expanders thanks to their class and add them their functionnality
function setExpanders(node) {
	for (var i=0; i<node.childNodes.length; i++) {
		var firstNode = node.childNodes[i];
		for (var j = (firstNode.childNodes.length -1); j >= 0; j--) {
			if (firstNode.childNodes[j].tagName == 'LI') {
				if(/expander/.test(firstNode.childNodes[j].className)) {
					firstNode.childNodes[j].onclick = function() {
						toggleExpander(this);
					};
					toggleExpander(firstNode.childNodes[j]);
				}
			}
		}
	}
}

// *********** toggleExpander ***********
// Hide/show the X previous elements before the expander (X is defined in the expander tag by the "level" attribute)
function toggleExpander(expander) {
	var i = expander.getAttribute('level');
	var currentNode = expander;
	var nodeType = currentNode.nodeName;
	while (i > 0) {
		if(currentNode.previousSibling.nodeName == nodeType) {
			if ((currentNode.previousSibling.style.display == '') || (currentNode.previousSibling.style.display == 'block')) {
				currentNode.previousSibling.style.display = 'none';
			}
			else {
				currentNode.previousSibling.style.display = 'block';
			}
			i--;
		}
		currentNode = currentNode.previousSibling;
	}
	if (expander.className == 'expander') {
		expander.className = 'expander expanded';
	}
	else {
		expander.className = 'expander';
	}
}