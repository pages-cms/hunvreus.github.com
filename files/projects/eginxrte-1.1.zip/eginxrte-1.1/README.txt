INSTALLATION
------------
1. DOWNLOAD EGINXRTE
   Download the latest version from http://teddy.fr/projects/egin-xrte

2. UNCOMPRESS AND UPLOAD
   Uncompress the archive and upload its content on your website.
   
3. LINK THE SCRIPTS
   Link the eginxrte.compressed.js and html2xhtml.js scripts as well as the
   rte.compressed.css stylesheet on your web page:
   
   <style type="text/css" media="all">@import "$RTEPATH/eginxrte.compressed css";</style>
   <script type="text/javascript" src="$RTEPATH/eginxrte.compressed.js"></script>
   
   With $RTEPATH the path to the folder where you uploaded eginXRTE.
   
4. DECLARE RICH TEXT INPUTS
   To declare a Rich Text input, simply put a textarea tag with the RTE class
   and eventually some of the optional attributes as described below :
   
   <textarea class="RTE"
	         name="$NAME"
	         height="$HEIGHT"
	         width="$WIDTH"
	         style="$STYLE"
	         cssFile="$CSSFILE"
	         $READONLY>$CONTENT</textarea>
   
   With :
     - $NAME : the name of the field
     - $HEIGHT (optional) : the height of the editable input, set to 250px by
	   default
     - $WIDTH (optional) : the width of the editable input, set to 100% by
	   default
     - $STYLE (optional) : the width and height defined here override the
	   $HEIGHT and $WIDTH values
     - $CSSFILE (optional) : the path to the stylesheet for the editable
	   content
     - $READONLY (optional) : as for a classical textarea, set to readonly if 
	   the content is displayed but not editable
     - $CONTENT : default content of the editable input

You can include as many RTE as you want in a single page.

CREDITS
-------
This script was developed by Ronan Berder <berder@teddy.fr>, based on Kevin
Roth's Rich Text Editor (http://www.kevinroth.com/rte/demo.htm).
Icons were created by Ronan Berder <berder@teddy.fr>.

LICENSE
-------
This script is completely free for non-commercial and commercial uses.
Pictures provided with this script are licensed under a Creative Commons
Attribution 3.0 License (http://creativecommons.org/licenses/by/3.0/).