/**
 * Exception Library
 *
 * This library implements exception objects and functions.
 *
 * @package egin
 * @subpackage global
 * @author Ronan BERDER <hunvreus[at]gmail[dot]com>
 * @copyright 2005 Ronan BERDER
 */
 
const EX_CLIENT = 1;
const EX_SERVER = 2;
 
/**
 * Exception constructor.
 *
 * @param {code} the exception code
 * @param {message} the exception message
 */
function EX_exception (code, localization, message) {
	this.code = code;
	this.localization = localization;
	this.message = message;
}

/**
 * Display the exception error message.
 *
 * @param {object} the exception to deal with
 */
function EX_defaultHandler (exception) {
	alert('Error : ' + exception.message + '.');
}