/**
 * Text Editor library.
 *
 * @package egin
 * @subpackage fileManager
 * @author Ronan BERDER <berder[at]teddy[dot]fr>
 * @copyright 2005 Ronan BERDER
 */

/**
 * File variables.
 */
var TE_file;
var TE_editor;

/**
 * UI elements ID.
 */
const TE_FILE_NAME_ID = 'TE_fileName'
const TE_FILE_CONTENT_ID = 'TE_fileContent'

const EGIN_FM_SERVER = 'http://localhost/eginxrte2/connector.php';

function TE_initializeEditorWindow() {
  TE_file = window.arguments[0];
  document.getElementById(TE_FILE_NAME_ID).setAttribute('value', TE_file.name);
  TE_editor = document.getElementById(TE_FILE_CONTENT_ID);
  TE_editor.makeEditable('text', true);
  TE_editor.setAttribute('src', EGIN_SERVER + '?document=fileSource&name=' + TE_file.name + '&path=' + TE_file.path);
  // The editor add a <br> athe end of the document that we must delete
  TE_editor.addEventListener("load", TE_cleanContent,true);
}

function TE_cleanContent() {
  var editor = TE_editor.getEditor(TE_editor.contentWindow);
  var editorBody = editor.rootElement;
  if ((editorBody.lastChild.tagName == 'BR') && (editorBody.lastChild.innerHTML != '')) {
    editor.deleteNode(editorBody.lastChild);
  }
}

function TE_resetContent() {
  var confirmation = confirm('Are you sure you want to reload the file content ? This will erase all your previous changes.');
  if(confirmation) {
      TE_editor.setAttribute('src', '');
      TE_initializeEditorWindow();
  }
}

/**
 * Intends to get the content of the specified file
 *
 * This function uses the XHR library. The XMLHTTPRequest response will be handled by the
 * FM_browseContentPath_response.
 * function.
 * 
 * @see XHR library
 */
function TE_saveContent() {
  var editor = TE_editor.getEditor(TE_editor.contentWindow);
  var content = editor.outputToString('text/plain', 0);
  XHR_request('POST', EGIN_SERVER, 'action=setChildContent&path=' + encodeURIComponent(TE_file.path) + '&name=' + encodeURIComponent(TE_file.name) + '&content=' + encodeURIComponent(content), null, 'TE_saveContent_response');
}

function TE_displayContent() {
  var editor = TE_editor.getEditor(TE_editor.contentWindow);
  var content = editor.outputToString('text/html', 0);
  alert(content);
}

function TE_saveContent_response(request) {
  var responseInfo = XHR_defaultResponseParse(request);
}