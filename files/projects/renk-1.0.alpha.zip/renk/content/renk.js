/**
 * File manager library.
 *
 * This library manage navigation and actions of the file manager main interface.
 *
 * @author Ronan BERDER <berder[at]teddy[dot]fr>
 * @copyright 2005 Ronan BERDER
 */

/**
 * Navigation variables
 */
var FM_previousHistory = new Array();
var FM_nextHistory = new Array();
var FM_currentHistory = '';
var FM_clipBoard = new Object();
FM_clipBoard.name = '';
FM_clipBoard.path = '';
FM_clipBoard.type = '';

/**
 * Commands IDs
 */
const FM_ATTRIBUTES_CMD = 'cmd_FM_attributes';
const FM_BROWSE_CMD = 'cmd_FM_browse';
const FM_COPY_CMD = 'cmd_FM_copy';
const FM_CUT_CMD = 'cmd_FM_cut';
const FM_DELETE_CMD = 'cmd_FM_delete';
const FM_DOWNLOAD_CMD = 'cmd_FM_download';
const FM_EDIT_CMD = 'cmd_FM_edit';
const FM_MOVE_CMD = 'cmd_FM_move';
const FM_NEXT_CMD = 'cmd_FM_goNext';
const FM_PARENT_CMD = 'cmd_FM_goParent';
const FM_PASTE_CMD = 'cmd_FM_paste';
const FM_PLAY_CMD = 'cmd_FM_play';
const FM_PREVIOUS_CMD = 'cmd_FM_goPrevious';
const FM_RENAME_CMD = 'cmd_FM_rename';
const FM_VIEW_CMD = 'cmd_FM_view';


/**
 * UI elements IDs
 */
const FM_CONTENT_ID = 'FM_Content';
const FM_CONTENT_PATH_ID = 'FM_ContentPath';
const FM_EDIT_POPUP_ID = 'FM_popupEdit';
const FM_BROWSE_POPUP_ID = 'FM_popupBrowse';
const FM_PLAY_POPUP_ID = 'FM_popupPlay';
const FM_SEPARATOR_POPUP_ID = 'FM_popupFirstSeparator';
const FM_TREE_ID = 'FM_Tree';
const FM_VIEW_POPUP_ID = 'FM_popupView';

const EGIN_SERVER = 'http://localhost/eginxrte2/connector.php';

/**
 * Intends to browse the path specified in the current path field.
 *
 * This function uses the XHR library. The XMLHTTPRequest response will be handled by the
 * FM_browseContentPath_response.
 * function.
 *
 * @see XHR library
 */
function FM_browseContentPath() {
  var path = document.getElementById(FM_CONTENT_PATH_ID).value;
  XHR_request('GET', EGIN_SERVER + '?action=browsePath&path=' + encodeURIComponent(path), null, null, 'FM_browseContentPath_response');
}

/**
 * Treats a XMLHTTPRequest which checks if a path can be browsed.
 * If no exception is thrown (which means the path can be browsed), gets the resolved path, browses
 * the path and updates the history.
 *
 * @param {object} the request sent back by the XMLHTTPRequest
 * @see XHR library
 */
function FM_browseContentPath_response(request) {
  var responseInfo = XHR_defaultResponseParse(request);
  var path = responseInfo['data']['path'];
  FM_browsePath(path);
  FM_updateHistory(path);
  FM_updateHistoryCommands();
}

/**
 * Browses the double-clicked directory.
 *
 * @param {string} the id of the tree in which the directory is selected
 * @param {event} the event thrown by the double-click
 */
function FM_browseDoubleClicked(treeID, event) {
  if (event.button == 0) {
    if (event.target.tagName == 'treechildren') {
      FM_openSelected(treeID);
    }
  }
}

/**
 * Browses the specified path.
 *
 * @param {string} the id of the tree in which the directory is selected
 */
function FM_browsePath(path) {
  document.getElementById(FM_CONTENT_ID).datasources = EGIN_SERVER + '?document=directoryContent.rdf&path=' + encodeURIComponent(path);
  FM_updateContentPath(path);
}

/**
 * Stores the selected file/directory parent path and name, then updates the paste command.
 */
function FM_copySelected() {
  var name = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Name");
  FM_clipBoard.path = FM_currentHistory;
  FM_clipBoard.name = name;
  FM_clipBoard.type = 'copy';
  document.getElementById(FM_PASTE_CMD).setAttribute('disabled', 'false');
}

/**
 * Stores the selected file/directory parent path and name, then updates the paste command.
 */
function FM_cutSelected() {
  var name = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Name");
  FM_clipBoard.path = FM_currentHistory;
  FM_clipBoard.name = name;
  FM_clipBoard.type = 'cut';
  document.getElementById(FM_PASTE_CMD).setAttribute('disabled', 'false');
}

/**
 * Intends to create a directory.
 *
 * This function uses the XHR library. The response will be handled by the
 * FM_createDirectory_response function.
 *
 * @see XHR library
 */
function FM_createDirectory() {
  var name = prompt('Directory name','New directory');
  if (name) {
    XHR_request('GET', EGIN_SERVER + '?action=createDirectory&path=' + encodeURIComponent(FM_currentHistory) + '&name=' + encodeURIComponent(name), null, null, 'FM_createDirectory_response');
  }
}

/**
 * Treats a XMLHTTPRequest which intends to create a directory.
 * If no exception is thrown (which means the directory has been created), refreshes the interface.
 *
 * @param {object} the request sent back by the XMLHTTPRequest
 */
function FM_createDirectory_response(request) {
  var responseInfo = XHR_defaultResponseParse(request);
  FM_refreshElement(FM_CONTENT_ID);
  FM_refreshElement(FM_TREE_ID);
}

/**
 * Intends to create a file.
 *
 * This function uses the XHR library. The response will be handled by the FM_createFile_response
 * function.
 *
 * @see XHR library
 */
function FM_createFile() {
  var name = prompt('File name','New file');
  if (name) {
    XHR_request('GET', EGIN_SERVER + '?action=createFile&path=' + encodeURIComponent(FM_currentHistory) + '&name=' + encodeURIComponent(name), null, null, 'FM_createFile_response');
  }
}

/**
 * Treats a XMLHTTPRequest which intends to create a file.
 * If no exception is thrown (which means the file has been created), refreshes the interface.
 *
 * @param {object} the request sent back by the XMLHTTPRequest
 */
function FM_createFile_response(request) {
  var responseInfo = XHR_defaultResponseParse(request);
  FM_refreshElement(FM_CONTENT_ID);
}

/**
 * Intends to delete a file/directory.
 *
 * This function uses the XHR library. The response will be handled by the
 * FM_deleteSelected_response function.
 *
 * @see XHR library
 */
function FM_deleteSelected() {
  var name = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Name");
  var confirmation = confirm('Do you really want to delete ' + name + ' ?');
  if (confirmation) {
    XHR_request('GET', EGIN_SERVER + '?action=deleteChild&name=' + encodeURIComponent(name) + '&path=' + encodeURIComponent(FM_currentHistory), null, null, 'FM_deleteSelected_response');
  }
}

/**
 * Treats a XMLHTTPRequest which intends to delete a file/directory.
 * If no exception is thrown (which means the file/directory has been deleted), refreshes the
 * interface.
 *
 * @param {object} the request sent back by the XMLHTTPRequest
 * @see XHR library
 */
function FM_deleteSelected_response(request) {
  var responseInfo = XHR_defaultResponseParse(request);
  FM_refreshElement(FM_CONTENT_ID);
  FM_refreshElement(FM_TREE_ID);
}

/**
 * Intends to edit the attributes of a file/directory.
 *
 * This function uses the XHR library. The response will be handled by the
 * FM_editAttributes_response function.
 *
 * @see XHR library
 */
function FM_editAttributes(path, name, attributes) {
  XHR_request('GET', EGIN_SERVER + '?action=setAttributes&attributes=' + encodeURIComponent(attributes) + '&name=' + encodeURIComponent(name) + '&path=' + encodeURIComponent(path), null, null, 'FM_editAttributes_response');
}

/**
 * Treats a XMLHTTPRequest which intends to edit the attributes of a file/directory.
 * If no exception is thrown (which means the file/directory attributes have been edited),
 * refreshes the interface.
 *
 * @param {object} the request sent back by the XMLHTTPRequest
 * @see XHR library
 */
function FM_editAttributes_response(request) {
  var responseInfo = XHR_defaultResponseParse(request);
  FM_refreshDirectoryContent();
}

/**
 * Displays the attributes edition window.
 */
function FM_editSelectedAttributes() {
  var file = new Object();
  file.attributes = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"IntegerAttributes");
  file.name = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Name");
  file.type = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Type");
  window.openDialog('attributes.xul', 'FM_attributesWindow', 'centerscreen=yes, chrome, dependent=yes, modal=yes, resizable=no', file);
  if (file.attributes) {
    FM_editAttributes(FM_currentHistory, file.name, file.attributes);
  }
}

/**
 * Displays the content edition window.
 */
function FM_editSelectedContent() {
  var file = new Object();
  file.name = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Name");
  file.path = FM_currentHistory;
  window.openDialog('textEditor.xul', 'FM_textEditorWindow', 'centerscreen=yes, chrome, dependent=yes, resizable=yes, all,dialog=no', file);
}


/**
 * Gets the currently focused element id.
 *
 * The function tries to get the currently focused element id, if empty tries to recursively get
 * the id of the parents on two levels since XUL elements are sometimes composed of many inner
 * elements as for "textbox".
 *
 * @return {string} the id of the currently focused element
 */
function FM_getFocusElementId() {
  var focusedElementID = document.commandDispatcher.focusedElement.id;
  if (!focusedElementID) {
    focusedElementID = document.commandDispatcher.focusedElement.parentNode.id;
  }
  if (!focusedElementID) {
    focusedElementID = document.commandDispatcher.focusedElement.parentNode.parentNode.id;
  }
  return focusedElementID;
}

/**
 * Gets the value of the specified column value of the selected row.
 *
 * @param {string} the id of the tree
 * @param {string} the name of the column
 * @return {mixed} the value of the specified column for the selected row
 */
function FM_getSelectedRowValue(treeID, columnID) {
  var tree = document.getElementById(treeID);
  var column = tree.columns[columnID];
  return tree.view.getCellText(tree.currentIndex,column);
}

/**
 * Goes to the next path in the history.
 */
function FM_goNext() {
  if (FM_nextHistory.length) {
    FM_previousHistory.push(FM_currentHistory);
    FM_currentHistory = FM_nextHistory.pop();
    FM_browsePath(FM_currentHistory);
    FM_updateHistoryCommands();
  }
}

/**
 * Intends to go to the parent directory.
 *
 * This function uses the XHR library. The response will be handled by the
 * FM_deleteSelected_response function.
 *
 * @see XHR library
 */
function FM_goParent() {
  var path = FM_currentHistory + '/..';
  XHR_request('GET', EGIN_SERVER + '?action=browsePath&path=' + encodeURIComponent(path), null, null, 'FM_browseContentPath_response');
}

/**
 * Goes to the previous path in the history.
 */
function FM_goPrevious() {
    if (FM_previousHistory.length) {
        FM_nextHistory.push(FM_currentHistory);
        FM_currentHistory = FM_previousHistory.pop();
        FM_browsePath(FM_currentHistory);
    FM_updateHistoryCommands();
    }
}

/**
 * Displays the help window.
 */
function FM_help() {
  window.open(EGIN_SERVER + "?document=help.xul","FM_HelpWindow","centerscreen=yes, height=300, modal=yes, resizable=yes, width=300");
}

/**
 * Displays the help window.
 */
function FM_initializeMainWindow() {
  document.getElementById(FM_NEXT_CMD).setAttribute('disabled', 'true');
  document.getElementById(FM_PARENT_CMD).setAttribute('disabled', 'true');
  document.getElementById(FM_PREVIOUS_CMD).setAttribute('disabled', 'true');
    document.getElementById(FM_CONTENT_ID).datasources = EGIN_SERVER + '?document=directoryContent.rdf';
    document.getElementById(FM_TREE_ID).datasources = EGIN_SERVER + '?document=directoryTree.rdf';
  document.getElementById(FM_VIEW_CMD).setAttribute('disabled', 'true');
  document.getElementById(FM_VIEW_CMD).setAttribute('disabled', 'true');
  FM_setCommands();
  FM_setContentPopup();
}

/**
 * Opens the selected file/directory.
 *
 * When a directory is selected, gets the path and tries to browse it. This function uses the XHR
 * library. The response will be handled by the FM_browseContentPath_response function.
 * When a file is selected, gets the group and call the adapted function.
 *
 * @param {string} the id of the tree in which the directory is selected
 * @see XHR library
 */
function FM_openSelected(treeID) {
    var type = FM_getSelectedRowValue(treeID, treeID+"Type");
    switch (type) {
    case 'directory':
      var path = FM_getSelectedRowValue(treeID, treeID+"Path");
      XHR_request('GET', EGIN_SERVER + '?action=browsePath&path=' + encodeURIComponent(path), null, null, 'FM_browseContentPath_response');
      break;
    case 'file':
      var group = FM_getSelectedRowValue(treeID, treeID+"Group");
      switch (group) {
        case 'editable':
          FM_editSelectedContent();
          break;
        case 'media':
          FM_playSelected();
          break;
        case 'image':
          FM_viewSelected();
          break;
      }
      break;
    }
}

/**
 * Stores the selected file/directory path and updates the paste command.
 */
function FM_paste() {
  document.getElementById(FM_PASTE_CMD).setAttribute('disabled', 'true');
  var action = (FM_clipBoard.type == 'copy') ? 'copyChild' : 'moveChild';
  XHR_request('GET', EGIN_SERVER + '?action=' + action + '&path=' + encodeURIComponent(FM_clipBoard.path) + '&name=' + encodeURIComponent(FM_clipBoard.name) + '&destinationPath=' + encodeURIComponent(FM_currentHistory) , null, null, 'FM_paste_response');
  FM_clipBoard = new Array();
}

/**
 * Stores the selected file/directory path and updates the paste command.
 */
function FM_paste_response(request) {
    var responseInfo = XHR_defaultResponseParse(request);
  FM_refreshElement(FM_CONTENT_ID);
  FM_refreshElement(FM_TREE_ID);
}

/**
 * Opens the Media Player to visualize the selected media.
 */
function FM_playSelected() {
  var path = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Path");
  window.open("?document=mediaPlayer.xul&path="+path,"FM_MediaPlayerWindow","centerscreen=yes, height=300, modal=yes, resizable=yes, width=300");
}

/**
 * Refreshes the directory content.
 */
function FM_refreshDirectoryContent() {
    FM_refreshElement(FM_CONTENT_ID);
}

/**
 * Refreshes the directory tree.
 */
function FM_refreshDirectoryTree() {
    FM_refreshElement(FM_TREE_ID);
}

/**
 * Refreshes a tree datasource.
 *
 * @param {string} the id of the tree to refresh
 */
function FM_refreshElement(treeID) {
    document.getElementById(treeID).builder.refresh();
}

/**
 * Intends to rename a file/directory.
 *
 * This function uses the XHR library. The response will be handled by the FM_renameSelected_response
 * function.
 *
 * @see XHR library
 */
function FM_renameSelected() {
  var name = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Name");
  var newName = prompt('New name :',name);
  if (newName) {
    XHR_request('GET', EGIN_SERVER + '?action=renameChild&name=' + encodeURIComponent(name) + '&newName=' + encodeURIComponent(newName) + '&path=' + encodeURIComponent(FM_currentHistory), null, null, 'FM_renameSelected_response');
  }
}

/**
 * Treats a XMLHTTPRequest which intends to rename a file/directory.
 * If no exception is thrown (which means the file has been renamed), refreshes the interface.
 *
 * @param {object} the request sent back by the XMLHTTPRequest
 */
function FM_renameSelected_response(request) {
  var responseInfo = XHR_defaultResponseParse(request);
  FM_refreshElement(FM_CONTENT_ID);
  FM_refreshElement(FM_TREE_ID);
}

/**
 * Calls the adapted function when the "RETURN" key is pressed.
 *
 * This function is called when the "RETURN" key is pressed and tests the value of the id of the
 * currently focused element to determine the function to call.
 *
 * @param {event} the event thrown when the "RETURN" key is pressed
 */
function FM_returnKeySwitch(event) {
    var focusedElementId = FM_getFocusElementId();
  switch (focusedElementId) {
    case FM_TREE_ID:
      FM_openSelected(FM_TREE_ID);
      break;
    case FM_CONTENT_ID:
      FM_openSelected(FM_CONTENT_ID);
      break;
    case FM_CONTENT_PATH_ID:
      FM_browseContentPath();
      break;
  }
}

/**
 * Sets the commands availability according to the selected data.
 */
function FM_setCommands() {
  try {
    var group = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Group");
    var browseState = (group == 'directory') ? 'false' : 'true' ;
    var downloadState = (group != 'directory') ? 'false' : 'true' ;
    var editState = (group == 'editable') ? 'false' : 'true' ;
    var viewState = (group == 'image') ? 'false' : 'true' ;
    var playState = (group == 'media') ? 'false' : 'true' ;
    document.getElementById(FM_ATTRIBUTES_CMD).setAttribute('disabled', 'false');
    document.getElementById(FM_BROWSE_CMD).setAttribute('disabled', browseState);
    document.getElementById(FM_COPY_CMD).setAttribute('disabled', 'false');
    document.getElementById(FM_CUT_CMD).setAttribute('disabled', 'false');
    document.getElementById(FM_DELETE_CMD).setAttribute('disabled', 'false');
    document.getElementById(FM_DOWNLOAD_CMD).setAttribute('disabled', downloadState);
    document.getElementById(FM_EDIT_CMD).setAttribute('disabled', editState);
    // document.getElementById(FM_MOVE_CMD).setAttribute('disabled', 'false');
    document.getElementById(FM_PLAY_CMD).setAttribute('disabled', playState);
    document.getElementById(FM_RENAME_CMD).setAttribute('disabled', 'false');
    document.getElementById(FM_VIEW_CMD).setAttribute('disabled', viewState);
  }
  catch (e) {
    document.getElementById(FM_ATTRIBUTES_CMD).setAttribute('disabled', 'true');
    document.getElementById(FM_BROWSE_CMD).setAttribute('disabled', 'true');
    document.getElementById(FM_COPY_CMD).setAttribute('disabled', 'true');
    document.getElementById(FM_CUT_CMD).setAttribute('disabled', 'true');
    document.getElementById(FM_DELETE_CMD).setAttribute('disabled', 'true');
    document.getElementById(FM_DOWNLOAD_CMD).setAttribute('disabled', 'true');
    document.getElementById(FM_EDIT_CMD).setAttribute('disabled', 'true');
    // document.getElementById(FM_MOVE_CMD).setAttribute('disabled', 'true');
    if (!FM_clipBoard.name) {
      document.getElementById(FM_PASTE_CMD).setAttribute('disabled', 'true');
    }
    document.getElementById(FM_PLAY_CMD).setAttribute('disabled', 'true');
    document.getElementById(FM_RENAME_CMD).setAttribute('disabled', 'true');
    document.getElementById(FM_VIEW_CMD).setAttribute('disabled', 'true');
  }
}

/**
 * Sets the content popup.
 */
function FM_setContentPopup() {
  try {
    var group = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Group");
    var type = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Type");
    var separatorState = ((type == 'file') && (group == '')) ? 'none' : '';
  }
  catch (e) {
    var separatorState = 'none';
  }
  document.getElementById(FM_SEPARATOR_POPUP_ID).style.display = separatorState;
}

/**
 * Updates the content path field.
 *
 * @param {string} the value of the path to set.
 */
function FM_updateContentPath (path) {
    document.getElementById(FM_CONTENT_PATH_ID).value = path;
}

/**
 * Updates the navigation history.
 *
 * @param {string} the value of the path to add to the history
 */
function FM_updateHistory(path) {
    FM_previousHistory.push(FM_currentHistory);
    FM_nextHistory = new Array();
    FM_currentHistory = path;
  FM_updateHistoryCommands();
}

/**
 * Updates the navigation commands (previous, next and parent).
 */
function FM_updateHistoryCommands() {
    var previousState = (FM_previousHistory.length) ? 'false' : 'true';
  var nextState = (FM_nextHistory.length) ? 'false' : 'true';
  var parentState = (FM_currentHistory != "") ? 'false' : 'true';
  document.getElementById(FM_PREVIOUS_CMD).setAttribute('disabled', previousState);
  document.getElementById(FM_NEXT_CMD).setAttribute('disabled', nextState);
  document.getElementById(FM_PARENT_CMD).setAttribute('disabled', parentState);
}

/**
 * Opens the upload window.
 */
function FM_fileUpload() {
  var picker = Components.classes["@mozilla.org/filepicker;1"].createInstance(Components.interfaces.nsIFilePicker);
  picker.init(window, "Select a file to upload", picker.modeOpen);
  if(picker.show() == picker.returnOK && picker.file) {
    XHR_sendFileRequest('POST', EGIN_SERVER + '?action=uploadFile&path=' + encodeURIComponent(FM_currentHistory), picker.file, null, 'FM_fileUpload_response');
  }
}

function FM_fileUpload_response(request) {
  var responseInfo = XHR_defaultResponseParse(request);
  FM_refreshElement(FM_CONTENT_ID);
}

/**
 * Opens the Image Viewer to visualize the selected image.
 */
function FM_viewSelected() {
  var name = FM_getSelectedRowValue(FM_CONTENT_ID, FM_CONTENT_ID+"Name");
  window.openDialog('imageviewer.xul', 'FM_imageViewerWindow', 'centerscreen=yes, chrome, dependent=yes, resizable=yes, all,dialog=no', FM_currentHistory, name);
}