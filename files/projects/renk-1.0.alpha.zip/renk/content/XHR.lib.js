/**
 * XHR Library
 *
 * This library implements XMLHTTPRequest functions.
 *
 * @author Ronan BERDER <berder[at]teddy[dot]fr>
 * @copyright 2005 Ronan BERDER
 */

/**
 * Send an XMLHTTPRequest
 *
 * If the error function is not defined, uses XHR_defaultErrorHandler
 *
 * @param {string} type        the request url
 * @param {string} url        the request url
 * @param {string} parameters      the request url
 * @param {string} errorFunction    the name of the function which handles the errors
 * @param {string} responseFunction  the name of the function which handles the response
 * @throws Error
 * @return {string}          the name of the function which handles the response
 */
function XHR_request(type, url, parameters, errorFunction, responseFunction) {
  var request = new XMLHttpRequest();
  request.onreadystatechange=function() {
    if (request.readyState == 4) {
      try {
        if (request.status == 200) {
          eval(responseFunction + '(request);');
        }
        else {
          var error = new Error(1, 'could not join the server (' + request.status + ' error)');
          throw error;
        }
      }
      catch (e) {
        errorFunction = (errorFunction) ? errorFunction : 'XHR_defaultErrorHandler';
        eval(errorFunction + '(e);');
      }
    }
  }
  request.open(type, url, true);
  if (type == 'POST') {
    request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
  }
  request.send(parameters);
  return request;
}

/**
 * Parse a "standard" XMLHTTPRequest response and return the data in an array
 *
 * @param {XMLHttpRequest} request  the request to deal with
 * @throws ServerError
 * @return {Array} result        the parsed request
 */
function XHR_defaultResponseParse(request) {
  var response  = request.responseXML;
  var result = new Array();
  result['type'] = response.getElementsByTagName('response')[0].getAttribute('type');
  result['code'] = response.getElementsByTagName('code')[0].firstChild.data;
  result['message'] = response.getElementsByTagName('message')[0].firstChild.data;
  result['data'] = new Array();
  for (var i=0;  i<response.getElementsByTagName('variable').length; i++) {
    var variable = response.getElementsByTagName('variable')[i];
    var data = (variable.firstChild) ? variable.firstChild.data : '';
    result['data'][variable.getAttribute('name')] = data;
  }
  if (result['type'] == 'error') {
    var error = new ServerError(result['code'], result['message'], result['data']['file'], result['data']['line']);
    throw error;
  }
  return result;
}

/**
 * Default exception handler
 *
 * @param: {Error} e  exception to handle
 */
function XHR_defaultErrorHandler(e) {
  alert("Error\n" + "Code : " + e.code + "\nMessage : " + e.message);
}

/**
 * Constructor for server side exceptions
 *
 * @param: {Int} code      exception code
 * @param: {String} message  exception message
 * @param: {String} file    source file (server side)
 * @param: {String} line    source line (server side)
 */
function ServerError(code, message, file, line) {
   this.code = code;
  this.file = file;
  this.line = line;
  this.message = message;
   this.name = "ServerException";
}

///////////////////////////
// DEV DEV DEV DEV DEV DEV
///////////////////////////

function XHR_sendFileRequest(type, url, file, errorFunction, responseFunction) {
  const BOUNDARY="111222111";
  const MULTI="@mozilla.org/io/multiplex-input-stream;1";
  const FINPUT = "@mozilla.org/network/file-input-stream;1";
  const STRINGIS="@mozilla.org/io/string-input-stream;1";
  const BUFFERED="@mozilla.org/network/buffered-input-stream;1";
  const nsIMultiplexInputStream=Components.interfaces.nsIMultiplexInputStream;
  const nsIFileInputStream=Components.interfaces.nsIFileInputStream;
  const nsIStringInputStream=Components.interfaces.nsIStringInputStream;
  const nsIBufferedInputStream = Components.interfaces.nsIBufferedInputStream;
  var mis=Components.classes[MULTI].createInstance(nsIMultiplexInputStream);
  var fin=Components.classes[FINPUT].createInstance(nsIFileInputStream);
  fin.init(file,0x01,0444,4);
  var buf=Components.classes[BUFFERED].createInstance(nsIBufferedInputStream);
  buf.init(fin,4096);
  //3
  var hsis=Components.classes[STRINGIS].createInstance(nsIStringInputStream);
  var sheader=new String();
  sheader+="\r\n";
  sheader+="--"+BOUNDARY+"\r\nContent-disposition: form-data;name=\"addfile\"\r\n\r\n1";
  sheader+="\r\n"+"--"+BOUNDARY+"\r\n"
  sheader+="Content-disposition: form-data;name=\"filename\";filename=\""+file.leafName+"\"\r\n";
  sheader+="Content-Type: application/octet-stream\r\n";
  sheader+="Content-Length: "+file.fileSize+"\r\n\r\n";
  hsis.setData(sheader,sheader.length);
  //4
  var endsis=Components.classes[STRINGIS].createInstance(nsIStringInputStream);
  var bs=new String("\r\n--"+BOUNDARY+"--\r\n");
  endsis.setData(bs,bs.length);
  //5
  mis.appendStream(hsis);
  mis.appendStream(buf);
  mis.appendStream(endsis);
  //6
  var request = new XMLHttpRequest();
  request.onreadystatechange=function() {
    if (request.readyState == 4) {
      try {
        if (request.status == 200) {
          eval(responseFunction + '(request);');
        }
        else {
          var error = new Error(request.status, 'could not join the server (' + request.status + ' error)');
          throw error;
        }
      }
      catch (e) {
        errorFunction = (errorFunction) ? errorFunction : 'XHR_defaultErrorHandler';
        eval(errorFunction + '(e);');
      }
    }
  }
  request.open(type, url, true);
  request.setRequestHeader("Content-Length",(mis.available()-2));
  request.setRequestHeader("Content-Type","multipart/form-data; boundary="+BOUNDARY);
  request.send(mis);
}

function URLencode(sStr) {
  return escape(sStr).replace(/\+/g, '%2B').
  replace(/\"/g,'%22').
  replace(/\'/g, '%27').
  replace(/\//g,'%2F');  
}

function URLencodeBis(str) {
    len = str.length;
    res = new String();
    charOrd = new Number();
    
    for (i = 0; i < len; i++) {
        charOrd = str.charCodeAt(i);
        if ((charOrd >= 65 && charOrd <= 90) || (charOrd >= 97 && charOrd <= 122) || (charOrd >= 48 && charOrd <= 57) || (charOrd == 33) || (charOrd == 36) || (charOrd == 95)) {
            // this is alphanumeric or $-_.+!*'(), which according to RFC1738 we don't escape
            res += str.charAt(i);

        }
        else {
            res += '%';
            if (charOrd > 255) res += 'u';
            hexValStr = charOrd.toString(16);
            if ((hexValStr.length) % 2 == 1) hexValStr = '0' + hexValStr;
            res += hexValStr;
        }
    }

    return res;
}