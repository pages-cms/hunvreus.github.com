/**
 * Image viewer library.
 *
 * This library initializes the image viewer and enables image resizing.
 *
 * @author Ronan BERDER <berder[at]teddy[dot]fr>
 * @copyright 2005 Ronan BERDER
 */

/**
 * Image variables.
 */
var IV_path = '';
var IV_height = 0;
var IV_size = 100;
var IV_width = 0;
var IV_sizeCounter = 0;


/**
 * UI elements ID.
 */
const IV_LOADER_ID = 'IV_imageLoader';
const IV_HEIGHT_ID = 'IV_imageHeight';
const IV_IMAGE_ID = 'IV_image';
const IV_IMAGE_BOX_ID = 'IV_imageBox';
const IV_NAME_ID = 'IV_imageName';
const IV_SIZE_ID = 'IV_imageSize';
const IV_VIEWER_ID = 'IV_viewerBox';
const IV_WIDTH_ID = 'IV_imageWidth';

const EGIN_FM_SERVER = 'http://localhost/eginxrte2/connector.php';

/**
 * Sets the image to its real size.
 */
function IV_actualSize() {
  IV_zoomAt(100);
  IV_sizeCounter = 0;
}

/**
 * Fits the image to the viewer.
 */
function IV_fitToWindow() {
  var boxHeight = document.getElementById(IV_VIEWER_ID).boxObject.height;
  var boxWidth = document.getElementById(IV_VIEWER_ID).boxObject.width;
  var imageHeight = boxHeight;
  var imageWidth = boxHeight*IV_width/IV_height;
  if (imageWidth > boxWidth) {
    imageHeight = boxWidth*IV_height/IV_width;
    imageWidth = boxWidth;
  }
  document.getElementById(IV_IMAGE_ID).style.height = imageHeight + 'px';
  document.getElementById(IV_IMAGE_ID).style.width = imageWidth + 'px';
  IV_size = Math.round(100*imageHeight/IV_height);
  document.getElementById(IV_SIZE_ID).value = IV_size + '%';
  IV_sizeCounter = Math.round(4*Math.log(IV_size/100));
}

function IV_initializeViewerWindow() {
  IV_path = EGIN_FM_SERVER + '?document=fileSource&path=' + window.arguments[0] + '&name=' + window.arguments[1];
  document.getElementById(IV_IMAGE_ID).setAttribute('src', IV_path);
}

function IV_resetImageViewer() {
  document.getElementById(IV_IMAGE_ID).setAttribute('src', '');
}
/**
 * Initializes the image viewer.
 *
 * Sets the information fields and the size select box
 *
 * @param {DOM object} the image
 */
function IV_initializeImageViewer() {
  document.getElementById(IV_LOADER_ID).style.display = 'none';
  document.getElementById(IV_NAME_ID).setAttribute('value', window.arguments[1]);
  var viewerImage = new Image();
  viewerImage.src = IV_path;
  viewerImage.onload = function() {
    IV_height = viewerImage.height;
    IV_width = viewerImage.width;
    document.getElementById(IV_HEIGHT_ID).value = IV_height + ' px';
    document.getElementById(IV_SIZE_ID).value = IV_size + '%';
    document.getElementById(IV_WIDTH_ID).value = IV_width + ' px';
    var boxHeight = document.getElementById(IV_VIEWER_ID).boxObject.height;
    var boxWidth = document.getElementById(IV_VIEWER_ID).boxObject.width;
    if ((IV_height > boxHeight) || (IV_width > boxWidth)) {
      IV_fitToWindow();
    }
  };
}

/**
 * Zooms at the percentage when the "ENTER" key is pressed.
 *
 * @param {object} the key press event
 */
function IV_validateSize(event) {
  if (event.which == 13) {
    IV_zoomPercentage();
  }
}

/**
 * Zooms at the image with the specified percentage.
 *
 * @param {mixed} an integer or a string representing the required display percentage
 */
function IV_zoomAt(percentage) {
  percentage = String(percentage);
  percentage = percentage.replace(/ /, '');
  percentage = percentage.replace(/%/, '');
  var height = Math.round(IV_height*(percentage/100));
  var width = Math.round(IV_width*(percentage/100));
  IV_size = Math.round(percentage);
    document.getElementById(IV_IMAGE_ID).style.height = height + 'px';
  document.getElementById(IV_IMAGE_ID).style.width = width + 'px';
  document.getElementById(IV_SIZE_ID).value = IV_size + '%';
  return percentage;
}

/**
 * Zooms in the image.
 */
function IV_zoomIn() {
  IV_sizeCounter ++;
  var newSize = Math.exp(0.25*IV_sizeCounter)*100;
    IV_zoomAt(newSize);
}

/**
 * Zooms out the image.
 */
function IV_zoomOut() {
  IV_sizeCounter --;
  var newSize = Math.exp(0.25*IV_sizeCounter)*100;
    IV_zoomAt(newSize);
}

/**
 * Zooms at the image with the specified percentage.
 */
function IV_zoomPercentage() {
  var percentage = document.getElementById(IV_SIZE_ID).value;
  percentage = IV_zoomAt(percentage);
  IV_sizeCounter = Math.round(4*Math.log(percentage/100));
}