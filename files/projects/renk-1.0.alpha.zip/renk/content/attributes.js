/**
 * Attributes Library
 *
 * Attributes window functions : initialization and actions.
 *
 * @package egin
 * @subpackage fileManager
 * @author Ronan BERDER <hunvreus[at]gmail[dot]com>
 * @copyright 2005 Ronan BERDER
 */
 
/**
 * File variables
 */
var FM_fileAttributes = new Array();

/**
 * UI elements ID.
 */
const FM_FILE_NAME_ID = 'FM_fileName';
const FM_USER_ATTRIBUTES_ID = 'FM_userAttributes';
const FM_GROUP_ATTRIBUTES_ID = 'FM_groupAttributes';
const FM_OTHER_ATTRIBUTES_ID = 'FM_otherAttributes';

/**
 * Initializes the attributes window.
 */
function FM_initializeAttributesWindow() {
	var file = window.arguments[0];
	document.getElementById(FM_FILE_NAME_ID).setAttribute('value', file.name);
	document.getElementById(FM_FILE_NAME_ID).className = file.type;
	FM_fileAttributes[0] = String(Number(file.attributes[0]).toString(2));
	FM_fileAttributes[1] = String(Number(file.attributes[1]).toString(2));
	FM_fileAttributes[2] = String(Number(file.attributes[2]).toString(2));
	FM_setAttributesCheckboxes(FM_USER_ATTRIBUTES_ID, FM_fileAttributes[0]);
	FM_setAttributesCheckboxes(FM_GROUP_ATTRIBUTES_ID, FM_fileAttributes[1]);
	FM_setAttributesCheckboxes(FM_OTHER_ATTRIBUTES_ID, FM_fileAttributes[2]);
}

/**
 * Set a user type attributes.
 *
 * @param {string} the ID of the box containing the user checkboxes
 * @param {string} binary representation of the user attributes
 */
function FM_setAttributesCheckboxes(boxID, attributes) {
	var children = document.getElementById(boxID).childNodes;
	var j=0;
	for (var i=0; i<children.length; i++) {
		if (children[i].tagName == 'checkbox') {
			checked = Number(attributes[j]) ? true : false;
			children[i].checked = checked;
			j++;
		}
	}
}

/**
 * Get attributes for a specific type of user.
 *
 * @param {string} the box ID of the type of user.
 * @return {string} decimal representation of the attributes.
 */
function FM_getCheckboxesAttributes(boxID) {
	var children = document.getElementById(boxID).childNodes;
	var binaryAttributes = '';
	for (i=0; i<children.length; i++) {
		if (children[i].tagName == 'checkbox') {
			binaryAttributes += children[i].checked ? '1' : '0';
		}
	}
	var decimalAttributes = parseInt(binaryAttributes, 2);
	return decimalAttributes;
}

/**
 * Get the attributes.
 *
 * @return {bool} allows the window closure.
 */
function FM_validateAttributes() {
	window.arguments[0].attributes = String(FM_getCheckboxesAttributes(FM_USER_ATTRIBUTES_ID));
	window.arguments[0].attributes += String(FM_getCheckboxesAttributes(FM_GROUP_ATTRIBUTES_ID));
	window.arguments[0].attributes += String(FM_getCheckboxesAttributes(FM_OTHER_ATTRIBUTES_ID));
	return true;
}

/**
 * Get the attributes.
 *
 * @return {bool} allows the window closure.
 */
function FM_cancelAttributes() {
	window.arguments[0].attributes = false;
	return true;
}