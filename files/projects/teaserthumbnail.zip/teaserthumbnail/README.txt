Description
-----------
The Teaser Thumbnail module intends to provide a way to automatically generate
thumbnails for node teasers based on the pictures included in their body as
well as attachments.

Requirements
------------
Drupal 5+
Imagecache module

Installation
------------
1. Unpack the teaserthumbnail folder and contents in the modules directory of 
   your Drupal installation.
2. Go to 'administer/modules' and enable teaserthumbnail.
3. Visit the teaserthumbnail settings page; you must at least define the
   general settings for the module to work, as well as the content types that
   may have a thumbnail. You can define content type specific settings that
   will override the general settings.

Author
-------
Ronan Berder <berder@teddy.fr> - http://teddy.fr