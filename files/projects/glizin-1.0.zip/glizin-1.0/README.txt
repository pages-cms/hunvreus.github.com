Glizin v1.0 - An icon Set by Ronan Berder
Email: berder@teddy.fr
Website: http://teddy.fr
----------
This work is licensed under a 
Creative Commons Attribution 3.0 Unported License
(http://creativecommons.org/licenses/by/3.0/)